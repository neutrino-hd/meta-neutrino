--- SCReinit by PauleFoul
--- Version 0.32
local screinitver = "V0.33 HD51"

-- CHANGELOG
-- V0.30 - Anzeige Version in Headline eingebaut
-- V0.31 - Schalter und Anzeige für Softcam-Keys eingebaut
-- V0.32 - Anpassungen an die HD51

local posix = require "posix"

function script_path()
	return posix.dirname(debug.getinfo(2, "S").source:sub(2)).."/"
end


--- Deklaration
screinit = {}
screinit_hint = {}
bin_path = "/etc/neutrino/bin"
cam_path = "/etc/neutrino/cam"

screinit[1] = "Oscam"
screinit_hint[1] = "Oscam aktivieren"

screinit[2] = "Gbox"
screinit_hint[2] = "Gbox aktivieren"

screinit[3] = "CCcam"
screinit_hint[3] = "CCCam aktivieren"

screinit[10] = "CI+ deaktivieren"
screinit_hint[10] = "CI+ Funktionalität deaktivieren"

screinit[11] = "/var/bin/oscam -c /var/emu/oscam 2>&1 > /dev/console &"
screinit_hint[11] = "CI+ Funktionalität aktivieren"

screinit[12] = "Cardserver deaktivieren"
screinit_hint[12] = "Stoppt aktuellen Cardserver"

screinit[13] = "Softcam-Keys deaktivieren"
screinit_hint[13] = "CI+ Funktionalität deaktivieren"

screinit[14] = "Softcam-Keys aktivieren"
screinit_hint[14] = "CI+ Funktionalität aktivieren"



--- Funktionen
function trim(s)
		return (s:gsub("^%s*(.-)%s*$", "%1"))
end

function fileExist(file)
		if posix.access(file, f) == nil then return false end
		return true
end

function pidOf(prog)
		local r = ""
    local h = io.popen("pidof " .. prog, "r")
    if h ~= nil then
    		r = h:read("*a")
        if r ~= "" then r = string.gsub(r, "\n", "") end
        io.close( h )
		end
		return r
end

function pop(cmd)
       local f = assert(io.popen(cmd, 'r'))
       local s = assert(f:read('*a'))
       f:close()
       return s
end


function killemu()
		os.execute("rm "..""..cam_path.."".."/.*")

		if pidOf("oscam") ~= "" then
			local h = hintbox.new{caption="SCReinit", text="oscam wird gestoppt..."}
	    h:paint()
	    os.execute("systemctl stop oscam")
	    os.execute("systemctl disable oscam")
	    h:hide()
		end
		
end


function startemu(cam)
		if cam == "1" then
				if fileExist(bin_path.."".."/oscam") == true then
						hintbox_text = "oscam wird gestartet..."
						local h = hintbox.new{caption="SCReinit", text=hintbox_text}
				    h:paint()
				    os.execute("systemctl enable oscam")
				    os.execute("systemctl start oscam")
				    os.execute("pzapit -rz")
				    posix.sleep(3)
						h:hide()
				end
		elseif cam == "2" then
				if fileExist(bin_path.."".."/gbox") == true then
						hintbox_text = "gbox wird gestartet..."
						local h = hintbox.new{caption="SCReinit", text=hintbox_text}
				    h:paint()
				    os.execute("systemctl enable gbox")
				    os.execute("systemctl start gbox")
				    os.execute("pzapit -rz")
				    posix.sleep(3)
						h:hide()
				end		
		elseif cam == "3" then
				if fileExist(bin_path.."".."/cccam") == true then
						hintbox_text = "cccam wird gestartet..."
						local h = hintbox.new{caption="SCReinit", text=hintbox_text}
				    h:paint()
				    os.execute("systemctl enable cccam")
				    os.execute("systemctl start cccam")
				    os.execute("pzapit -rz")
				    posix.sleep(3)
						h:hide()
				end		
		end
end


function initemu(k, v)
		select = k
		cam = k
		if     select == "1" then
				killemu ()
				startemu (cam)
				menuanzeige ()				
				
		elseif     select == "2" then
				killemu ()
				startemu (cam)
				menuanzeige ()
		
		elseif     select == "3" then
				killemu ()
				startemu (cam)
				menuanzeige ()
	
		elseif     select == "12" then
				killemu ()	
				menuanzeige ()
				return MENU_RETURN.REPAINT	
				
		elseif     select == "13" then
				local h = hintbox.new{caption="SCReinit", text="SoftCam.Key deaktivieren"}
				os.execute("mv /var/keys/SoftCam.Key /var/keys/SoftCam.Off")
				return MENU_RETURN.EXIT_REPAINT
				
		elseif     select == "14" then
				local h = hintbox.new{caption="SCReinit", text="SoftCam.Key aktivieren"}
				os.execute("mv /var/keys/SoftCam.Off /var/keys/SoftCam.Key")
				return MENU_RETURN.EXIT_REPAINT
		
		end
end




function menuanzeige ()

		local i
		local m = menu.new{name="SCReinit".."                   "..screinitver, icon="lock"}
		m:addItem{type="back"}
		m:addItem{type="separatorline"}
		
		i = 1
		opt = { "Aktiv" ,"-" }
		
		if fileExist(bin_path.."".."/oscam") == true then
						oscamver = pop("/etc/neutrino/bin/oscam -V")
						oscamver = oscamver:match("Version: (.*)");
						if pidOf("oscam") ~= "" then
							m:addItem{type="chooser", name=screinit[1], action="initemu", options={opt[1], opt[2]}, id=1, icon=i, hint=screinit_hint[1].." "..trim(oscamver), hint_icon="hint_reload", directkey=RC[tostring(i)]}
						else	
							m:addItem{type="chooser", name=screinit[1], action="initemu", options={opt[2], opt[1]}, id=1, icon=i, hint=screinit_hint[1].." "..trim(oscamver), hint_icon="hint_reload", directkey=RC[tostring(i)]}
						end
						i = i+1
		end
		
		if fileExist(bin_path.."".."/gbox") == true then
						gboxver = pop("/etc/neutrino/bin/gbox -V")
						gboxver = gboxver:match("Version: (.*)");
						if pidOf("gbox") ~= "" then
							m:addItem{type="chooser", name=screinit[2], action="initemu", options={opt[1], opt[2]}, id=2, icon=i, hint=screinit_hint[1].." "..trim(gboxver), hint_icon="hint_reload", directkey=RC[tostring(i)]}
						else	
							m:addItem{type="chooser", name=screinit[2], action="initemu", options={opt[2], opt[1]}, id=2, icon=i, hint=screinit_hint[1].." "..trim(gboxver), hint_icon="hint_reload", directkey=RC[tostring(i)]}
						end
						i = i+1
		end
		
				if fileExist(bin_path.."".."/cccam") == true then
						if pidOf("cccam") ~= "" then
							m:addItem{type="chooser", name=screinit[3], action="initemu", options={opt[1], opt[2]}, id=3, icon=i, hint=screinit_hint[1], hint_icon="hint_reload", directkey=RC[tostring(i)]}
						else	
							m:addItem{type="chooser", name=screinit[3], action="initemu", options={opt[2], opt[1]}, id=3, icon=i, hint=screinit_hint[1], hint_icon="hint_reload", directkey=RC[tostring(i)]}
						end
						i = i+1
		end
		
		m:addItem{type="separatorline"}
		
				m:addItem{type="forwarder", name=screinit[12], action="initemu", id=12, icon="gelb", hint=screinit_hint[12], hint_icon="hint_reload", directkey=RC[red]}
				i = i+1
				
		
		if fileExist("/var/emu/ci+/.ci+") == true then
				m:addItem{type="separatorline"}
				m:addItem{type="forwarder", name=screinit[10], action="initemu", id=10, icon="rot", hint=screinit_hint[10], hint_icon="hint_reload", directkey=RC[red]}
				i = i+1
		else
				m:addItem{type="separatorline"}
				m:addItem{type="forwarder", name=screinit[11], action="initemu", id=11, icon="rot", hint=screinit_hint[11], hint_icon="hint_reload", directkey=RC[red]}
				i = i+1
		end
		
		
		if fileExist("/var/keys/SoftCam.Key") == true then
				m:addItem{type="separatorline"}
				m:addItem{type="forwarder", name=screinit[13], action="initemu", id=13, icon="blau", hint=screinit_hint[13], hint_icon="hint_reload", directkey=RC[blue]}
				i = i+1
		elseif fileExist("/var/keys/SoftCam.Off") == true then
				m:addItem{type="separatorline"}
				m:addItem{type="forwarder", name=screinit[14], action="initemu", id=14, icon="blau", hint=screinit_hint[14], hint_icon="hint_reload", directkey=RC[blue]}
				i = i+1
		end
		m:exec()
end

--- Menueanzeige
menuanzeige ()

