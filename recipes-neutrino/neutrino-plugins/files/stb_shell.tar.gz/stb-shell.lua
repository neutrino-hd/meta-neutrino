-- Plugin to start or stop the framebuffer shell
-- distributed under BSD-2-Clause License

caption = "STB-Shell"

os.execute("getty-toggle")
