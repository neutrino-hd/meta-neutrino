--[[
	RSS READER Plugin
	Copyright (C) 2014-2017,  Jacek Jendrzej 'satbaby'

	License: GPL

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public
	License as published by the Free Software Foundation; either
	version 2 of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	General Public License for more details.

	You should have received a copy of the GNU General Public
	License along with this program; if not, write to the
	Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
	Boston, MA  02110-1301, USA.
]]

--dependencies:  feedparser http://feedparser.luaforge.net/ ,libexpat,  lua-expat 
rssReaderVersion="Lua RSS READER v0.50"
local n = neutrino()
local FontMenu = FONT.MENU
local FontTitle = FONT.MENU_TITLE
local hasgumbo,gumbo = pcall(require,"gumbo")
local glob = {}
local conf = {}
feedentries = {} --don't make local
local addon = nil
local nothing,hva,hvb,hvc,hvd,hve="nichts",nil,nil,nil,nil,nil
local vPlay = nil
local epgtext = nil
local epgtitle = nil
local LinksBrowser = "/links.so"
local picdir = "/tmp/rssPics"

function get_confFile()
	return "/var/tuxbox/config/rss.conf"
end

function __LINE__() return debug.getinfo(2, 'l').currentline end


function pop(cmd)
       local f = assert(io.popen(cmd, 'r'))
       local s = assert(f:read('*a'))
       f:close()
       return s
end

function getdata(Url,outputfile)
	if Url == nil then return nil end
	if Curl == nil then
		Curl = curl.new()
	end
	local ret, data = Curl:download{url=Url,A="Mozilla/5.0;",maxRedirs=5,followRedir=true,o=outputfile }
	if ret == CURL.OK then
		if outputfile then
			return 1
		end
		return data
	else
		return nil
	end
end

function getFeedDataFromUrl(url)
	local data = getdata(url)
	if data then
--		fix for >>> couldn't parse xml. lxp says: junk after document element 
		local nB, nE = data.find(data, "</rss>")
		if nE and #data > nE then
			data = string.sub(data,0,nE)
		end
	else
		return nil
	end

	local error = nil
	local feedparser = require "feedparser"
	fp,error = feedparser.parse(data)
	if error then
		print("DEBUG ".. __LINE__())
		print(data) --  DEBUG
		print ("ERROR >> ".. error .. "\n###")
		local window,x,y,w,h = showWindow("DEBUG Output", data)
		window:hide()
		window = nil
	end
	data = nil
	return fp
end

function godirectkey(d)
	if d  == nil then return d end
	local  _dkey = ""
	if d == 1 then
		_dkey = RC.red
	elseif d == 2 then
		_dkey = RC.green
	elseif d == 3 then
		_dkey = RC.yellow
	elseif d == 4 then
		_dkey = RC.blue
	elseif d < 14 then
		_dkey = RC[""..d - 4 ..""]
	elseif d == 14 then
		_dkey = RC["0"]
	else
		-- rest
		_dkey = ""
	end
	return _dkey
end

function check_if_is_menu(tab,name)
	for index,value in ipairs(tab) do
		if value == name then
			return false
		end
	end
	return true
end

function info(infotxt,cap)
	if cap == nil then
		cap = "Information"
	end
	local h = hintbox.new{caption=cap, text=infotxt}
	if h then
		h:paint()
		get_input()
		h:hide()
	end
	h = nil
end

function get_input(ct,bRed,bGreen,bYellow,bBlue)
	local stop = false
	local ret = nil
	local msg, data = nil,nil
	repeat
		msg, data = n:GetInput(500)

		if msg == RC.up or msg == RC.page_up then
			ct:scroll{dir="up"}
		elseif msg == RC.down or msg == RC.page_down then
			ct:scroll{dir="down"}
		elseif bRed and msg == RC.red then
			stop = true
		elseif bGreen and msg == RC.green then
			stop = true
		elseif bYellow and msg == RC.yellow then
			stop = true
		elseif bBlue and msg == RC.blue then
			stop = true
		end
	until msg == RC.home or msg == RC.setup or stop
	if stop then
		ret = msg
	end
	return ret
end

function tounicode(c)
	c=tonumber(c)
	if c > 64 then
		c=c-64
		return "\xC3" .. string.format('%c', c)
	else
		return string.format('%c', c)
	end
end
function convHTMLentities(summary)
	if summary ~= nil then
		summary = summary:gsub("&#([0-9]+);",function(c) return tounicode(c) end)
	end
	return summary
end

--------------------------- new
function removeElemetsbyTagName(document,ename)
	local t = document:getElementsByTagName(ename)

	for i, element in ipairs(t) do
		element:remove()
	end

end

function removeElemetsbyTagName2(document,tagName,atrName)
	local t = document:getElementsByTagName(tagName)
	for i, element in ipairs(t) do
		local el = element:getAttribute(atrName)
		if el then 
			element:remove()
		end
	end
end

function gum(data)
	if data == nil or hasgumbo == nil then return nil end

	local document = gumbo.parse(data)
	local unlikelyCandidates = {"script"}
	for i, unlikely in ipairs(unlikelyCandidates) do
		removeElemetsbyTagName(document,unlikely)
	end
	local class ={ {"div","style"},{"ul","style"},{"section","style"},{"a","onclick"}}
	for i,unlikely  in pairs(class) do
		removeElemetsbyTagName2(document,unlikely[1],unlikely[2])
	end

	local myCandidates ={"style","ol","aside","figure","nav","form","footer"}
	for i,unlikely  in ipairs(myCandidates) do
		removeElemetsbyTagName(document,unlikely)
	end
	local div = document:getElementsByTagName("div")
	for i, element in ipairs(div) do
		local class = element:getAttribute("class")
		if class   then
			if class:find("iqad") or class:find("navi") or class:find("meta")or class:find("sub") or class:find("button") then
				element:remove()
			end

		end
	end

 	for i, element in ipairs(document.links) do
		local elink = element:getAttribute("href")
		if elink:sub(1, 4) == 'http' or elink:sub(1, 1) == '/' or elink:sub(#elink-3, #elink) ~= 'php' then
-- 				print("elonk:",elink)

		else
 			element:remove()
		end
	end
	local div = document:getElementsByTagName("ul")
	for i, element in ipairs(div) do
		local id = element:getAttribute("class")
		if id   then
			if id:find("navi")  or id:find("iqad")then
				element:remove()
			end
		end
	end

	local div = document:getElementsByTagName("p")
	for i, element in ipairs(div) do
		local id = element:getAttribute("class")
		if id   then
			if id:find("navi")  or id:find("iqad") then
				element:remove()
			end
		end
	end
	local div = document:getElementsByTagName("div")
	for i, element in ipairs(div) do
		local id = element:getAttribute("id")
		if id   then
			if id:find("navi")  or id:find("iqad")then
				element:remove()
			end
		end
	end
	local txt = document.body.textContent
	return txt
end

function all_trim(s)
	if s == nil then return "" end
	return s:match("^%s*(.-)%s*$")
end

function prepare_text(text)
	if text == nil then return nil end
	if #text < 1 then
		return text
	end
	text = text:gsub('<.->', "") -- remove  "<" alles zwischen ">"
	text = convHTMLentities(text)
	text = text:gsub("%s+\n", "\n")
 	text = all_trim(text)
	return text
end

function getMaxScreenWidth()
	local max_w = SCREEN.END_X - SCREEN.OFF_X
	return max_w
end

function getMaxScreenHeight()
	local max_h = SCREEN.END_Y - SCREEN.OFF_Y
	return max_h
end

function getSafeScreenSize(x,y,w,h)
	local maxW = getMaxScreenWidth()
	local maxH = getMaxScreenHeight()
	if w > maxW or w < 1 then
		w = maxW
	end
	if h > maxH or h < 1 then
		if h > maxH then
			w = maxW
		end
		h = maxH
	end
	if x < 0 or x+w > maxW then
		x = 0
	end
	if y < 0 or y+h > maxH then
		y = 0
	end
	return x,y,w,h
end

function paintPic(window,fpic,x,y,w,h)
	local cp = cpicture.new{parent=window, x=x, y=y, dx=w, dy=h, image=fpic}
	if window == nil then
		cp:paint()
	end
end

function paintText(x,y,w,h,picW,picH,CPos,text,window) --ALIGN_AUTO_WIDTH
	if x == 0 then
		x = 20
	end
	local pW,pH = 0,0
	local ct = ctext.new{parent=window,x=x, y=y, dx=w, dy=h, text=text, mode = "ALIGN_SCROLL | DECODE_HTML", font_text=Font}
	if window == nil then
		ct:paint()
	else
		local ctLines = ct:getLines()
		h = ctLines * n:FontHeight(FontMenu)
		h = h + window:headerHeight() + window:footerHeight()  + window:headerHeight()/2
		h = math.floor(h)
		if ctLines < 5 then
			pW = 0
			pH = picH
			h = h + picH
		else
			w = w + picW + 4
			pH = 0
			pW = picW + 4
			h = h + window:footerHeight()
		end
		x,y,w,h = getSafeScreenSize(x,y,w,h)
		window:setDimensionsAll(x,y,w,h)
		ct:setDimensionsAll(x+pW,y+pH,w,h)
		if CPos and CPos > 0 and CPos < 4 then
			window:setCenterPos{CPos}
		end
		if ctLines > 4 and picH < h - window:headerHeight() - window:footerHeight()  then
			y = y + (h - window:headerHeight() - window:footerHeight()- picH)/2
			y = math.floor(y)
		end
	end
	return ct,x,y,w,h 
end

function paintWindow(x,y,w,h,CPos,Title,Icon,RedBtn,GreBtn,YelBtn,BluBtn)
	local defaultW = math.floor(getMaxScreenWidth()- getMaxScreenWidth()/3)
	local defaultH = n:FontHeight(FontMenu)
	if w < 1 then
		w = defaultW
	end
	if h < 1 then
		h = defaultH
	end
	local window = cwindow.new{x=x, y=y, dx=w, dy=h, title=Title, icon=Icon,
		btnRed=RedBtn, btnGreen=GreBtn,btnYellow=YelBtn,btnBlue=BluBtn}
	h = h + window:footerHeight() + window:headerHeight()
	if Title and #Title > 1 then
		w = n:getRenderWidth(FontTitle,Title .. "wW")
		w = w + window:headerHeight() + 10 --icon
		if w < defaultW then
			w = defaultW
		end
		if w > getMaxScreenWidth()  then
			w = getMaxScreenWidth()
		end
	end
	x,y,w,h = getSafeScreenSize(x,y,w,h)
	window:setDimensionsAll(x,y,w,h)
	if CPos and CPos > 0 and CPos < 4 then
		window:setCenterPos{CPos}
	end
 	return window,x,y,w,h
end
function show_textWindow(tit_txt, txt)
	glob.m:hide()
	if txt == nil then return end
	if txt and #txt < 1 then
		return
	end
	txt = prepare_text(txt)
	local window,x,y,w,h = showWindow(tit_txt, txt)
	window:hide()
	window = nil
end

function showWindow(title,text,fpic,icon,bRed,bGreen,bYellow,bBlue)
	local x,y,w,h = 0,0,0,0
	local picW,picH = 0,0
	local maxW = getMaxScreenWidth()
	local maxH = getMaxScreenHeight()
	text = prepare_text(text)
	if fpic then 
		picW,picH = n:GetSize(fpic)
		if picW and picH then
			local maxPicSizeW,maxPicSizeH = math.floor(maxW/4),math.floor(maxH/2)
			if #text < 100 then 
				if #text < 10 then 
					maxPicSizeH = maxH
				else
					maxPicSizeH = maxH-(5*n:FontHeight(FontMenu))
				end
				maxPicSizeW = maxW 
			end
			if picH > maxPicSizeH or picW > maxW then
				picW,picH = rescalePic(picW,picH,maxPicSizeW,maxPicSizeH)
			end
			if picH < 150 and picW < 150 then
				picW,picH = rescalePic(picW,picH,picH*2,picW*2)
			end

			h = picH
		end
	end

	local wPosition = 3
	local cw,x,y,w,h = paintWindow(x,y,w,h,-1,title,icon,bRed,bGreen,bYellow,bBlue)

 	local ct,x,y,w,h = paintText(x,y,w,h,picW,picH,wPosition,text,cw)
	if fpic then
		if x > 15 then
			x = x-10
		end
		local cp = paintPic(cw,fpic,x,y,picW,picH)
	end

	cw:paint()
	local selected =  get_input(ct,bRed,bGreen,bYellow,bBlue)
	return cw , selected
end

function epgInfo(xres, yres, aspectRatio, framerate)
	local window,x,y,w,h = showWindow(epgtitle, epgtext)
	window:hide()
	window = nil
end
function checkdomain(feed,url)
	if not url:find("//") then
		local domain = nil
		if fp.feed.link then
			domain = fp.feed.link:match('^(%w+://[^/]+)')
		end
		if domain then
			url =  domain .. "/" .. url
		end
	end
	return url
end
function getMediUrls(idNr)
	local UrlVideo,UrlAudio = nil,nil
	local picUrl =  {}
	local feed = fp.entries[idNr]
	for i, link in ipairs(feed.enclosures) do
		local urlType =link.type
		local mediaUrlFound = false
		if link.url and urlType == "image/jpeg" then
			picUrl[#picUrl+1] =  link.url
			mediaUrlFound = true
		end
		if urlType == 'video/mp4' or  urlType == 'video/mpeg' or  
		   urlType == 'video/x-m4v' or  urlType == 'video/quicktime' then
			UrlVideo =  link.url
			mediaUrlFound = true
		end
		if urlType == 'audio/mp3' or urlType == 'audio/mpeg' then
			UrlAudio =  link.url
			mediaUrlFound = true
		end

		if mediaUrlFound == false and link.url then
			picUrl[#picUrl+1] = link.url:match ('(http.-%.jpg)')
		end
	end
	if not UrlVideo and feed.summary then
		UrlVideo = feed.summary:match('<source%s+src%s?=%s?"(.-)"%s+type="video/mp4">')
	end
	if #picUrl == 0 then
		local urls = {feed.summary, feed.content}
		for i,v in ipairs(urls) do
			if type(v) == "string" then
				v=v:gsub('src=""','')
				v=v:gsub("src=''",'')
				for url in v:gmatch ('[%-%s]src%s?=%s?["\']?(.-%.[JjGgPp][PpIiNn][Ee]?[GgFf])["\'%s]') do
					if url and #url > 4 then
						url = checkdomain(feed,url)
						if url ~= picUrl[#picUrl] then
							picUrl[#picUrl+1] =  url
						end
					end
				end
			end 
		end
	end
	if UrlVideo and UrlVideo:sub(1, 2) == '//' then
		UrlVideo =  'http:' .. UrlVideo
	end
	if UrlAudio and UrlAudio:sub(1, 2) == '//' then
		UrlAudio =  'http:' .. UrlAudio
	end
	glob.urlPicUrls = picUrl
	return UrlVideo , UrlAudio
end
function html2text(viewer,text)
	if text == nil then return nil end
	local tmp_filename = os.tmpname()
 	local fileout = io.open(tmp_filename, 'w+')
	if fileout then
		fileout:write(text .. "\n")
		fileout:close()
	end
	local cmd = viewer .. " " .. tmp_filename
	text = pop(cmd)
	os.remove(tmp_filename)
	return text
end

function checkHaveViewer()
	if hva == conf.htmlviewer then
		return true
	elseif hvb == conf.htmlviewer then
		return true
	elseif hvc == conf.htmlviewer then
		return true
	elseif hvd == conf.htmlviewer then
		return true
	elseif hve == conf.htmlviewer then
		return true
	elseif nothing == conf.htmlviewer then
		return false
	end
		return false
end

function showWithHtmlViewer(data)
	local txt = nil
	local viewer = nil
	if hve == conf.htmlviewer then
		viewer = conf.linksbrowserdir .. LinksBrowser .. " -dump"
		txt=html2text(viewer,data)
	elseif hvb == conf.htmlviewer then
		viewer= conf.bindir .. "/html2text -nobs -utf8"
		txt=html2text(viewer,data)
	elseif hvc == conf.htmlviewer then
		viewer= conf.bindir .. "/w3m -dump"
		txt=html2text(viewer,data)
	elseif hvd == conf.htmlviewer then
		txt = gum(data)
	elseif nothing == conf.htmlviewer then
		return nil
	end
	return txt
end

-----------------------------------------------
function paintMenuItem(id)
	glob.m:hide()
	glob.urlPicUrls  = {}
	local idNr = tonumber(id)
	local title    = fp.entries[idNr].title
	if title then
		title = title:gsub("\n", " ")
	end
	local text    = fp.entries[idNr].summary
	local UrlLink = fp.entries[idNr].link
	local fpic = nil
	local UrlVideo,UrlAudio = getMediUrls(idNr)
	if addon and UrlLink then
		local hasaddon,a = pcall(require,addon)
		if hasaddon then
			a.getAddonMedia(UrlLink)
			if a.VideoUrl then
				UrlVideo = a.VideoUrl
				a.VideoUrl = nil
			end
			if a.AudioUrl then
				UrlAudio = a.AudioUrl
				a.AudioUrl = nil
			end
			if a.PicUrl then
				glob.urlPicUrls[#glob.urlPicUrls+1] = a.PicUrl
				a.PicUrl = nil
			end
			if a.addText then
				if text == nil then
					text=""
				end
				text = text .. a.addText
				a.addText = nil
			end
			if a.newText then
				text = a.newText
				a.newText = nil
			end
		else
			info(addon .. ".lua not found in directory: " .. conf.addonsdir ,"ADDON: Error")
		end
	end
	if  not vPlay  and (UrlVideo or UrlAudio) then
		vPlay  =  video.new()
	end
	if  vPlay and text and #text > 1 then
		vPlay:setInfoFunc("epgInfo")
		epgtext = text
		epgtitle = title
	end
	if UrlVideo == UrlLink then
		UrlLink = nil
	end
	if UrlAudio == UrlLink then
		UrlLink = nil
	end
	if UrlLink and UrlLink:sub(1, 4) ~= 'http' then
		UrlLink = nil
	end
	if #glob.urlPicUrls > 0 then
		fpic=downloadPic(id,1)
	end

	if text == nil and fp.entries[idNr].content then
		text = fp.entries[idNr].content
	end

	if text == nil then
		if vPlay and UrlVideo then
			vPlay:PlayFile(title,UrlVideo,UrlVideo)
		elseif vPlay and UrlAudio then
			vPlay:PlayFile(title,UrlAudio,UrlAudio)
		end
		collectgarbage("count")
		return
	end

	local bRed,bGreen,bYellow,bBlue =  nil,nil,nil,nil
	if UrlVideo then bRed = "Play Video" end
	if UrlLink and checkHaveViewer() then bGreen = "Read Seite" end
	if #glob.urlPicUrls > 0 then
		bYellow = "Show Pic"
		if #glob.urlPicUrls > 1 then
			bYellow = bYellow .. "s"
		end
	end
	if UrlAudio then bBlue = "Play Audio" end
	local cw,selected =  showWindow(title,text,fpic,"hint_info",bRed,bGreen,bYellow,bBlue)
	cw:hide()
	cw = nil

	if selected == RC.red and vPlay and UrlVideo then
		vPlay:PlayFile(title,UrlVideo,UrlVideo)
	elseif checkHaveViewer() and selected == RC.green and UrlLink then
	if hva == conf.htmlviewer and UrlLink then
		os.execute(conf.linksbrowserdir .. LinksBrowser .. " -g " .. UrlLink)
	else
		local data = getdata(UrlLink)
		if data then
			local txt = showWithHtmlViewer(data)
			data = nil
			if txt then
				show_textWindow(title,txt)
			end
		end
	end

	elseif selected == RC.yellow and  bYellow then
		picviewer(id,1)
	elseif selected == RC.blue and UrlAudio and vPlay then
		vPlay:PlayFile(title,UrlAudio,UrlAudio)
	end
	epgtext = nil
	epgtitle = nil
	if #glob.urlPicUrls > 0 and conf.picdir == picdir then
		local fh = filehelpers.new()
		if fh then
			fh:rmdir(picdir)
			fh:mkdir(picdir)
		end
		glob.urlPicUrls = nil
		fh = nil
	end
	collectgarbage("count")
end

function downloadPic(id,nr)
	local fpic = nil
	if not glob.urlPicUrls[nr] then return nil end
	local picname = string.find(glob.urlPicUrls[nr], "/[^/]*$")
	if picname then
		picname = string.sub(glob.urlPicUrls[nr],picname+1,#glob.urlPicUrls[nr])
		local t = nil 
		local idNr = tonumber(id)
		if fp.entries[idNr].updated_parsed then
		      t = os.date("%d%m%H%M%S_",fp.entries[idNr].updated_parsed)
		end
		local id2 = nil
		if t then
			id2 = t
		else
			id2 = id
		end
		fpic = conf.picdir .. "/" .. id2 .. picname
		local fh = filehelpers.new()
		if fh:exist(fpic, "f") == false then
			if nr > 1 then
				n:PaintIcon("icon_red", 20, 30, 30,30)
			end
			local UrlPic = glob.urlPicUrls[nr]
			if UrlPic:sub(1, 2) == '//' then
				UrlPic =  'http:' .. UrlPic
			end
			local ok = getdata(UrlPic,fpic)
			if not ok then
				fpic = nil
			end
		end
		fh = nil
	end
	return fpic
end

function rescalePic(picW,picH,maxW,maxH)
	local aspect = picW / picH
	if not maxH then
		maxH = getMaxScreenHeight()
	end
	if not maxW then
		maxW = getMaxScreenWidth()
	end
	if picW / maxW > picH / maxH then
		picW = maxW
		picH = maxW/aspect
	else
		picH = maxH
		picW = maxH * aspect
	end
	picH = math.floor(picH)
	picW = math.floor(picW)
	return picW,picH
end

function picviewer(id,nr)
	if #glob.urlPicUrls > 0 and nr > 0 then
		local V = nil
		local msg, data = nil,nil
		local lastnr = 0
		repeat
			msg, data = n:GetInput(500)

			if msg == RC.left then
				if nr > 1 then
					nr=nr-1
				else
					nr = #glob.urlPicUrls
				end
			elseif msg == RC.right then
				if nr < #glob.urlPicUrls then
					nr=nr+1
				else
					nr = 1
				end
			end
			if lastnr ~= nr then
				lastnr = nr
				local image = downloadPic(id,nr)
				if image then
					local picW,picH = n:GetSize(image)
					if picH < 250 and picW < 250 then
						picW,picH = rescalePic(picW,picH,picH*2,picW*2)
					else
						picW,picH = rescalePic(picW,picH)
					end
					local y,x=0,0
					if getMaxScreenHeight() > picH then
						y = (getMaxScreenHeight()-picH)/2
						y = math.floor(y)
					end
					if getMaxScreenWidth() > picW then
						x = (getMaxScreenWidth()-picW)/2
						x = math.floor(x)
					end
					n:PaintBox(0,0,-1,-1,COL.BLACK )
					n:DisplayImage(image,x,y,picW,picH)
					if #glob.urlPicUrls > 1 then
						local str = nr .. "/" .. #glob.urlPicUrls
						n:RenderString(FontMenu, str, 20, 30, COL.WHITE)
					end
				end
			end
		until msg == RC.home or msg == RC.setup or stop
		n:PaintBox(-1,-1,-1,-1,COL.BACKGROUND)
	end
end
-- ---------------------------------------------------------------------------
function rssurlmenu(url)
	local feedpersed = getFeedDataFromUrl(url)
	if feedpersed == nil then return end 
	local d = 0 -- directkey
	local m = menu.new{name=feedpersed.feed.title, icon="icon_blue"}
	glob.m=m
	m:addKey{directkey=RC.home, id="home", action="home"}
	m:addKey{directkey=RC.info, id="FEED Version: " .. fp.version, action="info"}
	m:addItem{type="back"}
	m:addItem{type="separator"}

	for i = 1, #feedpersed.entries do
		d = d + 1
		local dkey = godirectkey(d)
		local title =""
		if fp.entries[i].updated_parsed then
		      title = os.date("%d.%m %H:%M",fp.entries[i].updated_parsed)
		end
		if feedpersed.entries[i].title then
			title= title .. " "..feedpersed.entries[i].title:gsub("\n", " ")
		else
			title = title .. " "
		end
		m:addItem{type="forwarder", name=title, action="paintMenuItem", id=i, directkey=dkey }
	end
	m:exec()
end

function exec_url(id)
	glob.sm:hide()
	local nr = tonumber(id)
	addon = feedentries[nr].addon
	rssurlmenu(feedentries[nr].exec)
end
function exec_urlsub(id)
	glob.subm:hide()
	local nr = tonumber(id)
	addon = feedentries[nr].addon
	rssurlmenu(feedentries[nr].exec)
end
function exec_submenu(id)
	glob.sm:hide()
	local d = 0 -- directkey
	local subm = menu.new{name=id, icon="icon_yellow"}
	glob.subm=subm
	for v, w in ipairs(feedentries) do
		if w.submenu == id then
			if w.exec == "SEPARATOR" then
				subm:addItem{type="separator"}
			elseif w.exec == "SEPARATORLINE" then
				subm:addItem{type="separatorline", name=w.name}
			else
				d = d + 1
				local dkey = godirectkey(d)
				subm:addItem{type="forwarder", name=w.name, action="exec_urlsub", id=v, directkey=dkey }
			end
		end
	end
	subm:exec()
end

function home()
	return MENU_RETURN.EXIT
end
function saveConfig()
	if conf.changed then
		local config	= configfile.new()
		if config then
			config:setString("picdir", conf.picdir)
			config:setString("bindir", conf.bindir)
			config:setString("addonsdir", conf.addonsdir)
			config:setString("htmlviewer", conf.htmlviewer)
			config:setString("linksbrowserdir", conf.linksbrowserdir)
			config:saveConfig(get_confFile())
			config = nil
		end
		conf.changed = false
	end
end
function checkhtmlviewer()
	local fh = filehelpers.new()
	if fh:exist(conf.linksbrowserdir .. LinksBrowser, "f") == true then
		hva="links browser"
		hve="links viewer"
	end
	if fh:exist(conf.bindir .. "/" .. "html2text", "f") == true then
		hvb="html2text"
	end
	if fh:exist(conf.bindir .. "/" .. "w3m" , "f") == true then
		hvc="w3m"
	end
	if hasgumbo == true then
		hvd="gumbo"
	end

end

function loadConfig()
	local config	= configfile.new()
	if config then
		config:loadConfig(get_confFile())
		conf.picdir = config:getString("picdir", "/tmp/rssPics")
		conf.bindir = config:getString("bindir", "/bin")
		conf.addonsdir = config:getString("addonsdir", "/var/tuxbox/plugins/rss_addon/")
		conf.linksbrowserdir = config:getString("linksbrowserdir", "/var/tuxbox/plugins/")
		conf.htmlviewer = config:getString("htmlviewer", "nichts")
		config = nil
	end
	conf.changed = false
	checkhtmlviewer()
end

function set_action(id,value)
	conf[id]=value
	conf.changed = true
	if id == 'addonsdir' then
 		package.path = package.path .. ';' .. conf.addonsdir .. '/?.lua'
	end
	if id == 'linksbrowserdir' or id == 'bindir' then
		checkhtmlviewer()
	end
end

function settings()
	glob.sm:hide()

	local d =  1
	local menu =  menu.new{name="Einstellungen", icon="icon_blue"}
	glob.settings_menu = menu
	menu:addItem{type="back"}
	menu:addItem{type="separatorline"}
	menu:addItem{ type="filebrowser", dir_mode="1", id="picdir", name="Pic Verzeichnis: ", action="set_action",
		   enabled=true,value=conf.picdir,directkey=godirectkey(d),
		   hint_icon="hint_service",hint="In welchem Verzeichnis soll das Pics gespeichert werden ?"
		 }
	d=d+1
	menu:addItem{ type="filebrowser", dir_mode="1", id="bindir", name="Addon Verzeichnis: ", action="set_action",
		   enabled=true,value=conf.bindir,directkey=godirectkey(d),
		   hint_icon="hint_service",hint="In welchem Verzeichnis befinden sich html viewer ?"
		 }
	d=d+1
	menu:addItem{ type="filebrowser", dir_mode="1", id="addonsdir", name="Addon Verzeichnis: ", action="set_action",
		   enabled=true,value=conf.addonsdir,directkey=godirectkey(d),
		   hint_icon="hint_service",hint="In welchem Verzeichnis befinden sich rss addons ?"
		 }
	d=d+1
	menu:addItem{ type="filebrowser", dir_mode="1", id="linksbrowserdir", name="Links Browser Verzeichnis: ", action="set_action",
		   enabled=true,value=conf.linksbrowserdir,directkey=godirectkey(d),
		   hint_icon="hint_service",hint="In welchem Verzeichnis befinden sich Liks Browser ?"
		}
	d=d+1
	menu:addItem{type="chooser", action="set_action", options={ nothing,hva,hvb,hvc,hvd,hve }, id="htmlviewer", value=conf.htmlviewer, name="Browser Auswahl",directkey=godirectkey(d),hint_icon="hint_service",hint="Browser oder Html viewer Auswahl"}

	menu:exec()
	menu:hide()
	menu = nil
	return MENU_RETURN.EXIT_REPAINT
end
function start()
	local submenus = {}
	local d = 0 -- directkey
	local sm = menu.new{name="Lua RSS READER", icon="icon_blue"}
	glob.sm=sm
	sm:addKey{directkey=RC.favorites, id="settings", action="settings"}
	sm:addKey{directkey=RC.home, id="home", action="home"}
	sm:addKey{directkey=RC.info, id=rssReaderVersion, action="info"}
	for v, w in ipairs(feedentries) do
		if w.submenu and check_if_is_menu(submenus,w.submenu) then
			submenus[#submenus+1]=w.submenu
			d = d + 1
			local dkey = godirectkey(d)
			sm:addItem{type="forwarder", name=w.submenu, action="exec_submenu", id=w.submenu, directkey=dkey }
		end
	end
	if #submenus then
		sm:addItem{type="separatorline"}
	end
	for v, w in ipairs(feedentries) do
		if not w.submenu then
			if w.exec == "SEPARATOR" then
				sm:addItem{type="separator"}
			elseif w.exec == "SEPARATORLINE" then
				sm:addItem{type="separatorline", name=w.name}
			else
				d = d + 1
				local dkey = godirectkey(d)
				sm:addItem{type="forwarder", name=w.name, action="exec_url", id=v, directkey=dkey }
			end
		end
	end
	sm:exec()
end

function main()
	local config="/var/tuxbox/config/rssreader.conf"
	local fh = filehelpers.new()
	if fh:exist(config, "f") == false and fh:exist(config, "l") == false then
		feedentries = {
			{ name = "rssreader.conf Beispiel",		exec = "SEPARATORLINE" },
			{ name = "heise.de",		exec = "https://www.heise.de/newsticker/heise-atom.xml", submenu="TechNews"},
			{ name = "CHIP Hardware-News",	exec = "http://www.chip.de/rss/rss_technik.xml", submenu="TechNews"},
			{ name = "Tatort - ARD Mediathek", exec = "http://www.ardmediathek.de/tv/Tatort/Sendung?documentId=602916&bcastId=602916&rss=true", submenu="Podcast", addon="ard"},
			{ name = "KingOfSat News",	exec = "http://de.kingofsat.net/rssnews.php",submenu="SatInfo",addon="kingofsat"},
			{ name = "DB2W Forum",		exec = "https://dbox2world.net/board-feed/"},
		}
	else
		dofile(config)
	end
	fh:mkdir(picdir)

	loadConfig()

	if conf.picdir == nil or fh:exist(conf.picdir , "d") == false then
		conf.picdir = picdir
	end

	package.path = package.path .. ';' .. conf.addonsdir .. '/?.lua'
	if next(feedentries) == nil then
		print("DEBUG ".. __LINE__())
		print("failed while loading " .. config)
		return
	end
	start()
	saveConfig()
 	fh:rmdir(picdir)
end
main()
