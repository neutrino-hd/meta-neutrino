local media = {}
function media.getAddonMedia(url)
	local data = getdata(url)
	if data then
		for sat in data:gmatch('<fieldset.->(.-)</fieldset>') do
			sat = sat:gsub('</ul>', "\n")
			sat = sat:gsub('<.->', "")
			sat = sat:gsub('&deg;',"°")
			media.addText = sat .."\n"
		end	
	end
end
return media
