local media = {}
function media.getAddonMedia(url)
	local json = require "json"
	local domain = 'http://www.ardmediathek.de/play/media/'
	local id = url:match('documentId=(%d+)$?')
	if id then
		local data = getdata(domain .. id)
		local jnTab = json:decode(data)
		media.VideoUrl=jnTab._mediaArray[2]._mediaStreamArray[3]._stream[2]
	end
end
return media
