-- Plugin to change the startup partition
-- (c) Markus Volk
-- distributed under BSD-2-Clause License

local n = neutrino()
local _dx = n:scale2Res(1000) 
local _dy = n:scale2Res(100)
local _x = SCREEN.OFF_X + (((SCREEN.END_X - SCREEN.OFF_X) - _dx) / 2)
local _y = SCREEN.OFF_Y + (((SCREEN.END_Y - SCREEN.OFF_Y) - _dy) / 2)

local w = cwindow.new{x=_x, y=_y, dx=_dx, dy=_dy, name="Startpartition auswählen", icon="info", btnRed="Partition 1", btnGreen="Partition 2", btnYellow="Partition 3", btnBlue="Partition 4"}
w:paint()

local keypressed = nil 
repeat
        msg, data = n:GetInput(500)
        if (msg == RC['red']) then
                os.execute("cp /boot/STARTUP_1 /boot/STARTUP")
        keypressed = true
    end
        if (msg == RC['green']) then
        os.execute("cp /boot/STARTUP_2 /boot/STARTUP")
        keypressed = true
        end
    if (msg == RC['yellow']) then
        os.execute("cp /boot/STARTUP_3 /boot/STARTUP")
        keypressed = true
    end
        if (msg == RC['blue']) then
        os.execute("cp /boot/STARTUP_4 /boot/STARTUP")
        keypressed = true
        end
until msg == RC['home'] or keypressed

w = cwindow.new{x=_x, y=_y, dx=_dx, dy=_dy, name="Die gewählte Partition starten?", icon="info", btnRed="ja", btnGreen="nein"}
w:paint()

repeat
        msg, data = n:GetInput(500)
        if (msg == RC['red']) then
                os.execute("systemctl reboot")
        end
until msg == RC['green'] or msg == RC['home']

w:hide()
